#!/bin/sh

# Usage: ./do-n.sh RUNS SESSION COND
# i.e. PMM-Strategy: ./do-n.sh 10 1 \""any\""
# i.e. PMM-Strategy: ./do-n.sh 10 1 \""pmm\""

actr=/usr/local/actr6/load-act-r-6.lisp

for a in `seq $1`
    do
        pref="\"${2}-${1}-local-${a}\""
        ccl -l $actr -b -l "load-iccm2012.lisp" -e "(progn (do-n 1 $3 $pref) (quit))"
    done

echo "Done."

exit
